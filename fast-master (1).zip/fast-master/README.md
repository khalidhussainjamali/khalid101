# █▀▀ ▄▀█ █▀ ▀█▀
  █▀░ █▀█ ▄█ ░█░
  
  pkg update
  pkg upgrade
  pkg install python2
  pkg install git
  pip2 install requests mechanize
  git clone this location
  cd Fast
  python2 Mraf2.py
